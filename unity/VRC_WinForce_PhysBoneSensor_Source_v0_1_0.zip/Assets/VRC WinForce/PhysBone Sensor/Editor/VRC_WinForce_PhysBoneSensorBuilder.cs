#if UNITY_EDITOR
using System;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEngine;

[InitializeOnLoad]
public static class VRC_WinForce_PhysBoneSensorBuilder
{
    private const string PrefabPath =
        "Assets/VRC WinForce/PhysBone Sensor/Prefabs/VRC_WinForce_PhysBoneSensor.prefab";

    private const string ParameterBase = "WinForceSensor";

    static VRC_WinForce_PhysBoneSensorBuilder()
    {
        EditorApplication.delayCall += TryAutoBuild;
    }

    [MenuItem("Tools/VRC WinForce/Rebuild PhysBone Sensor Prefab")]
    public static void RebuildPrefab()
    {
        if (!BuildPrefab(true))
        {
            EditorUtility.DisplayDialog(
                "VRC WinForce",
                "The PhysBone sensor could not be configured.\n\n" +
                "Make sure VRChat Avatars SDK and Modular Avatar are installed, " +
                "then run this menu item again.",
                "OK"
            );
        }
    }

    private static void TryAutoBuild()
    {
        BuildPrefab(false);
    }

    private static Type FindType(string fullName)
    {
        foreach (var asm in AppDomain.CurrentDomain.GetAssemblies())
        {
            try
            {
                var t = asm.GetType(fullName, false);
                if (t != null) return t;
            }
            catch { }
        }
        return null;
    }

    private static bool SetSerialized(UnityEngine.Object obj, string propertyName, Action<SerializedProperty> setter)
    {
        try
        {
            var so = new SerializedObject(obj);
            var p = so.FindProperty(propertyName);
            if (p == null) return false;
            setter(p);
            so.ApplyModifiedPropertiesWithoutUndo();
            return true;
        }
        catch
        {
            return false;
        }
    }

    private static void SetBoolIfPresent(UnityEngine.Object obj, string name, bool value)
    {
        SetSerialized(obj, name, p => p.boolValue = value);
    }

    private static bool BuildPrefab(bool log)
    {
        var physBoneType = FindType("VRC.SDK3.Dynamics.PhysBone.Components.VRCPhysBone");
        var boneProxyType = FindType("nadena.dev.modular_avatar.core.ModularAvatarBoneProxy");

        if (physBoneType == null || boneProxyType == null)
        {
            if (log)
                Debug.LogWarning("[VRC WinForce] Missing VRChat SDK or Modular Avatar.");
            return false;
        }

        EnsureFolders();

        var root = new GameObject("VRC_WinForce_PhysBoneSensor");
        try
        {
            root.transform.localPosition = Vector3.zero;
            root.transform.localRotation = Quaternion.identity;
            root.transform.localScale = Vector3.one;

            var sensorRoot = new GameObject("SensorRoot");
            sensorRoot.transform.SetParent(root.transform, false);
            sensorRoot.transform.localPosition = Vector3.zero;

            var sensorEnd = new GameObject("SensorEnd");
            sensorEnd.transform.SetParent(sensorRoot.transform, false);
            sensorEnd.transform.localPosition = new Vector3(0f, 0f, 0.12f);

            // Modular Avatar Bone Proxy: attach prefab to humanoid Hips at build time.
            var proxy = root.AddComponent(boneProxyType);
            SetSerialized(proxy, "boneReference", p => p.enumValueIndex = (int)HumanBodyBones.Hips);
            // Current Modular Avatar versions use 0 for AsChildAtRoot.
            SetSerialized(proxy, "attachmentMode", p => p.enumValueIndex = 0);

            // VRChat PhysBone
            var physBone = sensorRoot.AddComponent(physBoneType);

            // Root Transform
            SetSerialized(physBone, "rootTransform", p => p.objectReferenceValue = sensorRoot.transform);

            // Parameter base -> VRChat exposes WinForceSensor_Angle.
            SetSerialized(physBone, "parameter", p => p.stringValue = ParameterBase);

            // Keep this as a passive sensor.
            SetBoolIfPresent(physBone, "allowGrabbing", false);
            SetBoolIfPresent(physBone, "allowPosing", false);

            // Conservative defaults if these fields exist in the installed SDK.
            SetSerialized(physBone, "pull", p => p.floatValue = 0.2f);
            SetSerialized(physBone, "spring", p => p.floatValue = 0.35f);
            SetSerialized(physBone, "stiffness", p => p.floatValue = 0.15f);
            SetSerialized(physBone, "gravity", p => p.floatValue = 0f);
            SetSerialized(physBone, "immobile", p => p.floatValue = 0f);
            SetSerialized(physBone, "radius", p => p.floatValue = 0.02f);

            PrefabUtility.SaveAsPrefabAsset(root, PrefabPath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();

            if (log)
                Debug.Log("[VRC WinForce] PhysBone sensor prefab rebuilt: " + PrefabPath);

            return true;
        }
        catch (Exception ex)
        {
            Debug.LogError("[VRC WinForce] Could not build sensor prefab: " + ex);
            return false;
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(root);
        }
    }

    private static void EnsureFolders()
    {
        EnsureFolder("Assets", "VRC WinForce");
        EnsureFolder("Assets/VRC WinForce", "PhysBone Sensor");
        EnsureFolder("Assets/VRC WinForce/PhysBone Sensor", "Prefabs");
    }

    private static void EnsureFolder(string parent, string child)
    {
        var path = parent + "/" + child;
        if (!AssetDatabase.IsValidFolder(path))
            AssetDatabase.CreateFolder(parent, child);
    }
}
#endif
