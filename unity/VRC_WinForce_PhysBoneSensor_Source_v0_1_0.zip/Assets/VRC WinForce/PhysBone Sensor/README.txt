VRC WinForce - PhysBone Sensor v0.1.0

Purpose
-------
This package creates a small VRChat PhysBone sensor for VRC WinForce.

Expected OSC parameter:
  /avatar/parameters/WinForceSensor_Angle

PhysBone parameter base:
  WinForceSensor

Requirements
------------
- VRChat Avatars SDK
- Modular Avatar

After import
------------
If both dependencies are installed, the package automatically tries to build:
  Assets/VRC WinForce/PhysBone Sensor/Prefabs/VRC_WinForce_PhysBoneSensor.prefab

If the prefab was not configured automatically, use:
  Tools > VRC WinForce > Rebuild PhysBone Sensor Prefab

Usage
-----
1. Drag VRC_WinForce_PhysBoneSensor.prefab under the avatar root.
2. Modular Avatar Bone Proxy attaches it to Hips during the avatar build.
3. Upload the avatar normally.
4. VRC WinForce listens for:
     /avatar/parameters/WinForceSensor_Angle

Notes
-----
- The sensor object is invisible.
- Grabbing and posing are disabled where supported by the installed SDK.
- _Angle is a normalized PhysBone value, not degrees.
- The editor builder uses reflection so the package can import even if
  VRChat SDK or Modular Avatar are installed after this package.
